import re,ast,glob,sys
import numpy as np
for name in ['original','uci']:
    print('=====',name)
    cw=[];rw=[];rho=[];dtlast=0;lab=0
    for sp in (11,22,33,44,55):
        t=open(f'/tmp/claude-0/ext/split_{name}_{sp}.txt').read()
        clean=ast.literal_eval(re.search(r'clean AUC: (\{.*\})',t).group(1))
        rob={}
        for m in re.finditer(r'^(LR|DT|RF|SVM|KNN|XGB)\s+([\d.]+)\s+([\d.]+)$',t,re.M): rob[m.group(1)]=float(m.group(2))
        st=ast.literal_eval(re.search(r"^(\{'.*\})$",t,re.M).group(1))
        r=float(re.search(r'spearman clean vs robust rank (\S+)',t).group(1))
        c1=max(clean,key=clean.get); r1=max(rob,key=rob.get)
        crank=sorted(clean,key=lambda k:-clean[k]); rrank=sorted(rob,key=lambda k:-rob[k])
        print(sp,'clean',crank,'| robust',rrank,'| rho %.2f'%r,'| worst stress',min(st,key=st.get),'| DT last',rrank[-1]=='DT')
        cw.append(c1);rw.append(r1);rho.append(r)
    print('clean winners',cw,'robust winners',rw,'rho mean %.2f min %.2f max %.2f'%(np.mean(rho),min(rho),max(rho)))
    print('splits where clean winner != robust winner:',sum(a!=b for a,b in zip(cw,rw)))
