import sys, numpy as np, pandas as pd, warnings
warnings.filterwarnings("ignore")
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.base import clone
from sklearn.metrics import roc_auc_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from xgboost import XGBClassifier
from scipy.stats import spearmanr
name, path = sys.argv[1], sys.argv[2]
SPLIT=int(sys.argv[3])
d = pd.read_csv(path)
if name=='uci':
    d = d.rename(columns={'sex':'gender','cp':'chestpain','trestbps':'restingBP','chol':'serumcholestrol','fbs':'fastingbloodsugar','restecg':'restingrelectro','thalach':'maxheartrate','exang':'exerciseangia','ca':'noofmajorvessels'}).drop(columns=['thal'])
    d['noofmajorvessels']=d['noofmajorvessels'].fillna(d['noofmajorvessels'].median())
elif name=='cleveland':
    d = d.rename(columns={'sex':'gender','cp':'chestpain','trestbps':'restingBP','chol':'serumcholestrol','fbs':'fastingbloodsugar','restecg':'restingrelectro','thalach':'maxheartrate','exang':'exerciseangia','ca':'noofmajorvessels'}).drop(columns=['thal'])
else:
    d = d.drop(columns=['patientid'])
y = d['target']; X = d.drop(columns=['target']).astype(float)
Xtr,Xte,ytr,yte = train_test_split(X,y,test_size=.2,stratify=y,random_state=SPLIT)
models = {
 "LR":Pipeline([("s",StandardScaler()),("m",LogisticRegression(max_iter=2000,random_state=42))]),
 "DT":Pipeline([("m",DecisionTreeClassifier(random_state=42))]),
 "RF":Pipeline([("m",RandomForestClassifier(n_estimators=200,random_state=42,n_jobs=1))]),
 "SVM":Pipeline([("s",StandardScaler()),("m",SVC(probability=True,random_state=42))]),
 "KNN":Pipeline([("s",StandardScaler()),("m",KNeighborsClassifier())]),
 "XGB":Pipeline([("m",XGBClassifier(n_estimators=200,max_depth=4,learning_rate=.05,subsample=.9,colsample_bytree=.9,objective="binary:logistic",eval_metric="logloss",random_state=42,n_jobs=1))]),
}
D={"restingBP":[0,3,5,8,10],"serumcholestrol":[0,5,10,15,20],"maxheartrate":[0,3,5,8,10],"oldpeak":[0,.1,.25,.5,.75]}
def meas(Xi,sev,seed):
    rng=np.random.default_rng(seed); Xo=Xi.copy().reset_index(drop=True)
    for c,dl in D.items():
        m=dl[min(int(round(sev*20)),4)]
        if m==0: continue
        Xo[c]=(Xo[c]+rng.choice([-1.,1.],size=len(Xo))*rng.uniform(0,m,size=len(Xo))).clip(Xtr[c].min(),Xtr[c].max())
    return Xo
def mcar(Xi,sev,seed):
    rng=np.random.default_rng(seed); Xo=Xi.copy().reset_index(drop=True)
    if sev==0: return Xo
    return Xo.mask(rng.random(Xo.shape)<sev)
def fdm(Xi,sev,seed):
    rng=np.random.default_rng(seed); Xo=Xi.copy().reset_index(drop=True)
    if sev==0: return Xo
    b=np.full(Xo.shape,sev,float)
    for c in ["restingBP","serumcholestrol","oldpeak"]:
        v=Xo[c].astype(float).values; z=(v-np.nanmin(v))/(np.nanmax(v)-np.nanmin(v)+1e-12)
        b[:,Xo.columns.get_loc(c)]=sev*(.5+z)
    return Xo.mask(rng.random(Xo.shape)<np.clip(b,0,1))
def imp(a,b):
    m=a.median(numeric_only=True); return a.fillna(m),b.fillna(m)
def flip(yi,sev,seed):
    rng=np.random.default_rng(seed); yo=np.asarray(yi).copy(); n=int(round(len(yo)*sev))
    if n>0: yo[rng.choice(len(yo),n,replace=False)]=1-yo[rng.choice(len(yo),0)] if False else 0
    return yo
def flip(yi,sev,seed):
    rng=np.random.default_rng(seed); yo=np.asarray(yi).copy(); n=int(round(len(yo)*sev))
    if n>0:
        idx=rng.choice(len(yo),n,replace=False); yo[idx]=1-yo[idx]
    return yo
base={}
for k,m in models.items():
    m=clone(m).fit(Xtr,ytr); base[k]=roc_auc_score(yte,m.predict_proba(Xte)[:,1])
rows=[]
for st in ["Measurement","MCAR","Feature-Dependent","Label Noise"]:
  for sev in [0,.05,.1,.15,.2]:
    for r in range(10):
      seed=42+r*100+int(sev*1000); a,b,yy=Xtr.copy(),Xte.copy(),ytr.copy()
      if st=="Measurement": a,b=meas(a,sev,seed),meas(b,sev,seed+1)
      elif st=="MCAR": a,b=imp(mcar(a,sev,seed),mcar(b,sev,seed+1))
      elif st=="Feature-Dependent": a,b=imp(fdm(a,sev,seed),fdm(b,sev,seed+1))
      else: yy=flip(yy,sev,seed)
      for k,m in models.items():
        m=clone(m).fit(a,yy); rows.append((st,sev,r,k,roc_auc_score(yte,m.predict_proba(b)[:,1])))
R=pd.DataFrame(rows,columns=["st","sev","r","model","auc"])
R["IS"]=100*R.auc/R.model.map(base)
ov=R.groupby("model").IS.agg(["mean","min"]).sort_values("mean",ascending=False)
print(name,"n=",len(d),"pos=",int(y.sum()),"train/test",len(Xtr),len(Xte))
print("clean AUC:",{k:round(v,4) for k,v in sorted(base.items(),key=lambda x:-x[1])})
print(ov.round(3))
print(R.groupby("st").IS.mean().round(3).to_dict())
print(R.groupby(["model","st"]).IS.mean().unstack().round(2))
cr=pd.Series(base).rank(ascending=False); rr=ov["mean"].rank(ascending=False)
print("spearman clean vs robust rank", spearmanr(cr[ov.index],rr)[0])

